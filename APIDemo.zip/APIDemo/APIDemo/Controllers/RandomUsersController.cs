﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using APIDemo.Models;

namespace APIDemo.Controllers
{
    public class RandomUsersController : ApiController
    {
        private EmployeeDBEntities db = new EmployeeDBEntities();

        // GET: api/RandomUsers
        public IQueryable<RandomUser> GetRandomUsers()
        {
            return db.RandomUsers;
        }

        // GET: api/RandomUsers/5
        [ResponseType(typeof(RandomUser))]
        public IHttpActionResult GetRandomUser(int id)
        {
            RandomUser randomUser = db.RandomUsers.Find(id);
            if (randomUser == null)
            {
                return NotFound();
            }

            return Ok(randomUser);
        }

        // PUT: api/RandomUsers/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutRandomUser(int id, RandomUser randomUser)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != randomUser.ID)
            {
                return BadRequest();
            }

            db.Entry(randomUser).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RandomUserExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/RandomUsers
        [ResponseType(typeof(RandomUser))]
        public IHttpActionResult PostRandomUser(RandomUser randomUser)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.RandomUsers.Add(randomUser);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = randomUser.ID }, randomUser);
        }

        // DELETE: api/RandomUsers/5
        [ResponseType(typeof(RandomUser))]
        public IHttpActionResult DeleteRandomUser(int id)
        {
            RandomUser randomUser = db.RandomUsers.Find(id);
            if (randomUser == null)
            {
                return NotFound();
            }

            db.RandomUsers.Remove(randomUser);
            db.SaveChanges();

            return Ok(randomUser);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool RandomUserExists(int id)
        {
            return db.RandomUsers.Count(e => e.ID == id) > 0;
        }
    }
}